from .affipred import affipred
